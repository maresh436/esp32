The Audio folder contains the following files:
- ECWS_Audio_JustRead: Basic reading of the sound sensor wth ouput seen on the Serial plotter
- ECWS_Audio_DataGen: Generating datasets for two word - 'two' and 'six'
- ECWS_Inference_01: Inference code on ESP32 with the model in place for identification of two words - 'two' and 'six'
- model.h:model generated with two csv files for 'two' and 'six' 
