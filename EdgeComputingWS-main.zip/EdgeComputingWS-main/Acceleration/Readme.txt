This folder contains the following files:
- ECWS_6050: Basic read of the 3-axes MPU6050 sensor
- ECWS_6050_Dataset: Generating datasets for the following gestures: Left,Up and Punch
- ECWS_6050_Inference: Inference code for MPU6050 with the model in place
- model.h: Model generated from csv filesfor Left,Up and Punch gestures
