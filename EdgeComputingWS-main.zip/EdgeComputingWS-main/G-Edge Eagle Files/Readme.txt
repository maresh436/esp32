The folder contains the following Eagle files for the G_Edge board:
- Schematic file
- Board file
