The Temperature folder contains the following files:
- ECWS_DHT11:For basic DHT11 reading to get humidity and temperature
-ECWS_Dataset:For genearting datasets with 5 temperatures per record 
-ECWS_Inference: For running inference on the G-Edge board with the trained model
