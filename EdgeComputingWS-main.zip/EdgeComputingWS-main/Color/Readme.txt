The Color folder contains the following files:
ECWS_TCS3200: Basic reading of the TCS3200 color sensor 
ECWS_TCS3200_Dataset:RGB dataset generation for different colors
ECWS_Inference:Inference code for TCS3200 with the model in place
model.h: Model generated with red, blue, orange and no color 
