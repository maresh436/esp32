Hardware Design
