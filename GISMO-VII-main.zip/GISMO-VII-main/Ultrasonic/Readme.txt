The Ultrasonic module should be connected to the Grove port with VCC as 5 V 
The GPIO lines are 13 and 12
Trigger pin 12
Echo pin 13
Echo pin needs to be level translted (5V to 3.3V before being connected to the ESP32)
