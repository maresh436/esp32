# GISMO-VII
This version of GISMO is designed with Grove connectors   
The board has :  
2 Analog Grove ports  
2 Digital Grove ports  
2 I2C Grove ports  
1 UART Grove port  
1 Grove port with 5V supply
