The soil moisture sensor is connected to GPIO34
The relay is connected to GPIO25
