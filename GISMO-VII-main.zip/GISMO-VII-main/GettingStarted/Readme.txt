This folder contains the following files:
- LED connected to a digital Grove port
- Relay connected to a digital Grove port
- OLED connected to an I2C Grove port
