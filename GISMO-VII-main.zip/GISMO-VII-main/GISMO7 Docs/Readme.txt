This folder contains the following documents:  
- Hatdware schematic of GISMO7  
- Grove connector pinouts of GISMO7
